from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from database.models import Base, SanPham, NguyenLieu, CongThuc, NhanVien, KhuyenMai
from datetime import date, timedelta

engine = create_engine('sqlite:///cafe_pos.db')
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def init_db_and_seed():
    Base.metadata.create_all(bind=engine)
    session = SessionLocal()
    
    # Chỉ tạo duy nhất tài khoản Admin nếu DB trống
    if session.query(NhanVien).count() == 0:
        print("Đang khởi tạo CSDL trắng cho bản Thương Mại...")
        nv_admin = NhanVien(
            ten_nv="Chủ Quán", 
            ten_dang_nhap="admin", 
            mat_khau="123", 
            chuc_vu="Admin", 
            luong=0
        )
        session.add(nv_admin)
        session.commit()
        print("Hoàn tất! Mọi danh mục đều trống. Vui lòng tự thêm trong tool.")
        
    session.close()

def get_session():
    return SessionLocal()