from sqlalchemy import Column, Integer, String, Float, ForeignKey, DateTime, Date, Time
from sqlalchemy.orm import declarative_base, relationship
from datetime import datetime
from sqlalchemy import Date
from datetime import date

Base = declarative_base()

# ================= PHẦN 1: NHÂN SỰ & CA LÀM =================
class NhanVien(Base):
    __tablename__ = 'nhan_vien'
    id = Column(Integer, primary_key=True, autoincrement=True)
    ten_nv = Column(String(100), nullable=False)
    ten_dang_nhap = Column(String(50), unique=True, nullable=False)
    mat_khau = Column(String(100), nullable=False, default='123456') # Nên hash mật khẩu ở bản thực tế
    chuc_vu = Column(String(50)) # 'Admin', 'Quản lý', 'Nhân viên'
    luong = Column(Float)
    trang_thai = Column(String(50), default='Đang làm việc')

class CaLamViec(Base):
    __tablename__ = 'ca_lam_viec'
    id = Column(Integer, primary_key=True, autoincrement=True)
    ten_ca = Column(String(50), nullable=False)
    gio_bat_dau = Column(Time)
    gio_ket_thuc = Column(Time)

class PhanCongCaLam(Base):
    __tablename__ = 'phan_cong_ca_lam'
    id = Column(Integer, primary_key=True, autoincrement=True)
    ma_nv = Column(Integer, ForeignKey('nhan_vien.id'))
    ma_ca = Column(Integer, ForeignKey('ca_lam_viec.id'))
    ngay_lam = Column(Date, nullable=False)
    trang_thai_dd = Column(String(50), default='Chưa điểm danh')

# ================= PHẦN 2: KHO, MENU & KHUYẾN MÃI =================
class NguyenLieu(Base):
    __tablename__ = 'nguyen_lieu'
    id = Column(Integer, primary_key=True, autoincrement=True)
    ten_nl = Column(String(100))
    don_vi_tinh = Column(String(20))
    gia_nhap = Column(Float)
    so_luong_ton = Column(Float, default=0.0)
    # THÊM 2 CỘT NÀY:
    loai_nl = Column(String(50), default="Lâu dài") # "Lâu dài" hoặc "Trong ngày"
    ngay_cap_nhat = Column(Date, default=date.today)

class SanPham(Base):
    __tablename__ = 'san_pham'
    id = Column(Integer, primary_key=True, autoincrement=True)
    ten_sp = Column(String(100))
    gia_goc = Column(Float, default=0.0)
    gia_ban = Column(Float)
    trang_thai = Column(String(50), default='Đang bán')
    
    # Quan hệ với công thức
    cong_thuc = relationship("CongThuc", back_populates="san_pham")

    def calculate_base_cost(self):
        total = 0
        for ct in self.cong_thuc:
            total += ct.dinh_muc * ct.nguyen_lieu.gia_nhap
        return total

class CongThuc(Base):
    __tablename__ = 'cong_thuc'
    ma_sp = Column(Integer, ForeignKey('san_pham.id'), primary_key=True)
    ma_nl = Column(Integer, ForeignKey('nguyen_lieu.id'), primary_key=True)
    dinh_muc = Column(Float)
    
    san_pham = relationship("SanPham", back_populates="cong_thuc")
    nguyen_lieu = relationship("NguyenLieu")

class KhuyenMai(Base):
    __tablename__ = 'khuyen_mai'
    id = Column(Integer, primary_key=True, autoincrement=True)
    ten_km = Column(String(200), nullable=False)
    dk_tong_tien_tu = Column(Float, default=0.0)
    dk_so_luong_tu = Column(Integer, default=0)
    kieu_giam = Column(String(50)) # 'PhanTram' / 'TienMat'
    gia_tri_giam = Column(Float)
    toi_da_giam = Column(Float)
    ngay_bat_dau = Column(Date)
    ngay_ket_thuc = Column(Date)
    trang_thai = Column(String(50), default='Đang chạy')

# ================= PHẦN 3: BÁN HÀNG & HÓA ĐƠN =================
class KhachHang(Base):
    __tablename__ = 'khach_hang'
    id = Column(Integer, primary_key=True, autoincrement=True)
    ten_kh = Column(String(100))
    so_dien_thoai = Column(String(15))
    diem_tich_luy = Column(Integer, default=0)

class HoaDon(Base):
    __tablename__ = 'hoa_don'
    id = Column(Integer, primary_key=True, autoincrement=True)
    thoi_gian = Column(DateTime, default=datetime.now)
    ma_nv = Column(Integer, ForeignKey('nhan_vien.id'), nullable=True)
    ma_kh = Column(Integer, ForeignKey('khach_hang.id'), nullable=True)
    ma_km = Column(Integer, ForeignKey('khuyen_mai.id'), nullable=True)
    
    tong_tien = Column(Float, default=0.0)
    giam_gia = Column(Float, default=0.0)
    thue = Column(Float, default=0.0)
    thanh_tien = Column(Float, default=0.0)
    
    trang_thai = Column(String(50), default='Đã thanh toán')
    
    chi_tiet = relationship("ChiTietHoaDon", back_populates="hoa_don")
    khuyen_mai = relationship("KhuyenMai") # Lấy thông tin KM dễ dàng

class ChiTietHoaDon(Base):
    __tablename__ = 'chi_tiet_hoa_don'
    id = Column(Integer, primary_key=True, autoincrement=True)
    ma_hd = Column(Integer, ForeignKey('hoa_don.id'))
    ma_sp = Column(Integer, ForeignKey('san_pham.id'))
    so_luong = Column(Integer)
    don_gia = Column(Float)
    giam_gia = Column(Float, default=0.0)
    thanh_tien = Column(Float, default=0.0)
    
    hoa_don = relationship("HoaDon", back_populates="chi_tiet")
    san_pham = relationship("SanPham")