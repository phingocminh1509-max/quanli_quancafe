from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QListWidget, 
                               QStackedWidget, QWidget, QLabel, QPushButton, 
                               QTableWidget, QTableWidgetItem, QHeaderView, 
                               QMessageBox, QFormLayout, QLineEdit, QComboBox)
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from database.db_config import get_session
from database.models import NhanVien

# ==========================================
# 1. FORM THÊM / SỬA NHÂN VIÊN
# ==========================================
class EmployeeForm(QDialog):
    def __init__(self, parent=None, emp_id=None):
        super().__init__(parent)
        self.emp_id = emp_id
        self.setWindowTitle("Thiết Lập Tài Khoản Nhân Viên")
        self.resize(350, 250)
        self.setStyleSheet("""
            QDialog { background-color: #2D2D3F; color: white; }
            QLabel { color: white; font-weight: bold; }
            QLineEdit, QComboBox { background-color: #1A1A24; border: 1px solid #3E3E55; border-radius: 5px; padding: 5px; color: white; }
        """)

        layout = QFormLayout(self)
        self.txt_name = QLineEdit()
        self.txt_user = QLineEdit()
        self.txt_pass = QLineEdit()
        self.txt_pass.setEchoMode(QLineEdit.Password)
        self.cb_role = QComboBox()
        self.cb_role.addItems(["Nhân viên", "Admin"])

        layout.addRow("Tên hiển thị:", self.txt_name)
        layout.addRow("Tên đăng nhập:", self.txt_user)
        layout.addRow("Mật khẩu:", self.txt_pass)
        layout.addRow("Chức vụ:", self.cb_role)

        btn_save = QPushButton("💾 Lưu Tài Khoản")
        btn_save.setStyleSheet("background-color: #27AE60; color: white; font-weight: bold; height: 35px; margin-top: 10px; border-radius: 5px;")
        btn_save.clicked.connect(self.save_data)
        layout.addRow(btn_save)

        if self.emp_id:
            self.load_data()

    def load_data(self):
        session = get_session()
        emp = session.query(NhanVien).get(self.emp_id)
        if emp:
            self.txt_name.setText(emp.ten_nv)
            self.txt_user.setText(emp.ten_dang_nhap)
            self.txt_pass.setText(emp.mat_khau)
            self.cb_role.setCurrentText(emp.chuc_vu)
        session.close()

    def save_data(self):
        name = self.txt_name.text().strip()
        user = self.txt_user.text().strip()
        pwd = self.txt_pass.text().strip()
        role = self.cb_role.currentText()

        if not name or not user or not pwd:
            QMessageBox.warning(self, "Lỗi", "Vui lòng điền đầy đủ thông tin!")
            return

        session = get_session()
        try:
            if self.emp_id:
                emp = session.query(NhanVien).get(self.emp_id)
            else:
                # Kiểm tra trùng tên đăng nhập
                if session.query(NhanVien).filter_by(ten_dang_nhap=user).first():
                    QMessageBox.warning(self, "Lỗi", "Tên đăng nhập đã tồn tại!")
                    return
                emp = NhanVien()
                session.add(emp)

            emp.ten_nv = name
            emp.ten_dang_nhap = user
            emp.mat_khau = pwd
            emp.chuc_vu = role
            session.commit()
            self.accept()
        except Exception as e:
            QMessageBox.critical(self, "Lỗi", str(e))
        finally:
            session.close()

# ==========================================
# 2. GIAO DIỆN CÀI ĐẶT NÂNG CAO (DASHBOARD)
# ==========================================
class AdminSettingsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Cài Đặt Hệ Thống Nâng Cao")
        self.resize(900, 550)
        self.setStyleSheet("""
            QDialog { background-color: #1E1E2E; color: white; }
            QListWidget { background-color: #2D2D3F; border: none; border-radius: 10px; color: #A1A1AA; font-size: 14px; font-weight: bold; }
            QListWidget::item { padding: 15px; border-bottom: 1px solid #1E1E2E; }
            QListWidget::item:selected { background-color: #3498DB; color: white; border-radius: 8px; }
            QTableWidget { background-color: #2D2D3F; border: none; border-radius: 10px; gridline-color: #3E3E55; color: white; }
            QTableWidget::item { padding: 5px; }
            QHeaderView::section { background-color: #1A1A24; color: white; padding: 8px; border: none; font-weight: bold; }
        """)

        layout = QHBoxLayout(self)

        # --- CỘT TRÁI: MENU ĐIỀU HƯỚNG ---
        self.menu_list = QListWidget()
        self.menu_list.setFixedWidth(220)
        self.menu_list.addItems(["👥 Quản lý Nhân Sự", "💰 Bảng Lương (Sắp ra mắt)", "⚙️ Cấu hình Quán"])
        layout.addWidget(self.menu_list)

        # --- CỘT PHẢI: KHU VỰC NỘI DUNG (STACK) ---
        self.stack = QStackedWidget()
        layout.addWidget(self.stack)

        # Tab 1: Quản lý Nhân sự
        self.tab_employee = QWidget()
        self.setup_employee_tab()
        self.stack.addWidget(self.tab_employee)

        # Tab 2: Tính lương (Mockup/Demo)
        self.tab_payroll = QWidget()
        self.setup_payroll_tab()
        self.stack.addWidget(self.tab_payroll)

        # Tab 3: Cấu hình
        self.tab_config = QWidget()
        lbl_config = QLabel("Tính năng Cấu hình Quán đang được phát triển...")
        lbl_config.setAlignment(Qt.AlignCenter)
        QVBoxLayout(self.tab_config).addWidget(lbl_config)
        self.stack.addWidget(self.tab_config)

        # Lắng nghe sự kiện chuyển Tab
        self.menu_list.currentRowChanged.connect(self.stack.setCurrentIndex)
        self.menu_list.setCurrentRow(0)

    def setup_employee_tab(self):
        layout = QVBoxLayout(self.tab_employee)
        
        # Toolbar
        toolbar = QHBoxLayout()
        title = QLabel("DANH SÁCH TÀI KHOẢN NHÂN VIÊN")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #3498DB;")
        toolbar.addWidget(title)
        
        btn_add = QPushButton("➕ Cấp tài khoản mới")
        btn_add.setStyleSheet("background-color: #27AE60; font-weight: bold; padding: 8px; border-radius: 5px;")
        btn_add.clicked.connect(self.add_employee)
        toolbar.addWidget(btn_add, alignment=Qt.AlignRight)
        layout.addLayout(toolbar)

        # Bảng hiển thị
        self.emp_table = QTableWidget(0, 4)
        self.emp_table.setHorizontalHeaderLabels(["ID", "Tên Hiển Thị", "Tên Đăng Nhập", "Chức Vụ"])
        self.emp_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.emp_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.emp_table.itemDoubleClicked.connect(self.edit_employee) # Nhấp đúp để sửa
        layout.addWidget(self.emp_table)

        self.load_employees()

    def load_employees(self):
        self.emp_table.setRowCount(0)
        session = get_session()
        emps = session.query(NhanVien).all()
        for i, emp in enumerate(emps):
            self.emp_table.insertRow(i)
            self.emp_table.setItem(i, 0, QTableWidgetItem(str(emp.id)))
            self.emp_table.setItem(i, 1, QTableWidgetItem(emp.ten_nv))
            self.emp_table.setItem(i, 2, QTableWidgetItem(emp.ten_dang_nhap))
            
            role_item = QTableWidgetItem(emp.chuc_vu)
            if emp.chuc_vu == "Admin":
                role_item.setForeground(QColor("#E74C3C")) # Admin bôi đỏ
            self.emp_table.setItem(i, 3, role_item)
        session.close()

    def add_employee(self):
        if EmployeeForm(self).exec():
            self.load_employees()

    def edit_employee(self, item):
        row = item.row()
        emp_id = int(self.emp_table.item(row, 0).text())
        if EmployeeForm(self, emp_id).exec():
            self.load_employees()

    def setup_payroll_tab(self):
        """Khung giao diện tính lương để lấy điểm thuyết trình (Chưa nối DB sâu)"""
        layout = QVBoxLayout(self.tab_payroll)
        title = QLabel("TÍNH TOÁN LƯƠNG NHÂN VIÊN THÁNG NÀY")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #F1C40F;")
        layout.addWidget(title)

        table = QTableWidget(3, 4)
        table.setHorizontalHeaderLabels(["Tên Nhân Viên", "Số Ca Làm", "Lương/Ca", "Tổng Lương"])
        table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        
        # Dữ liệu Demo để khè giảng viên
        demo_data = [
            ("Thu Ngân 1", "22", "150,000", "3,300,000 đ"),
            ("Pha Chế 1", "26", "200,000", "5,200,000 đ"),
            ("Admin", "30", "500,000", "15,000,000 đ")
        ]
        for row, data in enumerate(demo_data):
            for col, text in enumerate(data):
                table.setItem(row, col, QTableWidgetItem(text))
        
        layout.addWidget(table)
        layout.addWidget(QLabel("<i>* Ghi chú: Module Chấm công & Tính lương đang trong giai đoạn hoàn thiện liên kết Database.</i>"))