from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QPushButton, 
                               QTreeWidget, QTreeWidgetItem, QHeaderView, 
                               QLineEdit, QMessageBox, QFormLayout, QWidget, 
                               QComboBox, QScrollArea, QLabel)
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QFont
from database.db_config import get_session
from database.models import SanPham, NguyenLieu, CongThuc

# ==========================================
# 1. FORM NHẬP LIỆU (ĐÃ THÊM CỘT TỒN KHO)
# ==========================================
class ProductForm(QDialog):
    def __init__(self, parent=None, product_id=None):
        super().__init__(parent)
        self.product_id = product_id
        self.setWindowTitle("Thiết Lập Món & Công Thức")
        self.resize(800, 500) 
        
        # === CSS MỚI SIÊU ĐẸP CHO FORM ===
        self.setStyleSheet("""
            QDialog { background-color: #1E1E2E; color: white; }
            QLabel { color: #E2E8F0; font-weight: bold; }
            QLineEdit, QComboBox {
                background-color: #2D2D3F; border: 1px solid #475569;
                border-radius: 6px; padding: 8px; color: white;
            }
            QLineEdit:focus, QComboBox:focus { border: 1px solid #3498DB; background-color: #35354A; }
            QScrollArea { border: none; background-color: transparent; }
            QWidget { background-color: transparent; }
        """)
        
        self.main_layout = QVBoxLayout(self)
        
        # --- THÔNG TIN MÓN CHÍNH ---
        form_layout = QFormLayout()
        self.txt_name = QLineEdit()
        self.txt_price = QLineEdit()
        form_layout.addRow("Tên Sản Phẩm:", self.txt_name)
        form_layout.addRow("Giá Bán (VNĐ):", self.txt_price)
        self.main_layout.addLayout(form_layout)
        
        # --- DANH SÁCH NGUYÊN LIỆU (ĐỘNG) ---
        self.ing_rows = [] 
        
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll_content = QWidget()
        self.ingredients_layout = QVBoxLayout(scroll_content)
        self.ingredients_layout.setAlignment(Qt.AlignTop)
        scroll.setWidget(scroll_content)
        
        self.main_layout.addWidget(QLabel("<b>THÀNH PHẦN NGUYÊN LIỆU:</b>"))
        self.main_layout.addWidget(scroll)
        
        btn_add_row = QPushButton("➕ Thêm Nguyên Liệu Cho Món Này")
        btn_add_row.setStyleSheet("background-color: #2980B9; color: white; font-weight: bold; padding: 5px;")
        btn_add_row.clicked.connect(self.add_ingredient_row)
        self.main_layout.addWidget(btn_add_row)
        
        btn_save = QPushButton("💾 LƯU MÓN & CÔNG THỨC")
        btn_save.setStyleSheet("background-color: #27AE60; color: white; font-weight: bold; height: 40px; margin-top: 10px;")
        btn_save.clicked.connect(self.save_data)
        self.main_layout.addWidget(btn_save)
        
        self.add_ingredient_row() 

    def add_ingredient_row(self):
        row_widget = QWidget()
        h_layout = QHBoxLayout(row_widget)
        h_layout.setContentsMargins(0, 5, 0, 5)

        txt_name = QLineEdit(); txt_name.setPlaceholderText("Tên NL (Sữa)")
        txt_qty = QLineEdit(); txt_qty.setPlaceholderText("Định mức/món")
        
        # --- THÊM Ô TỒN KHO ---
        txt_stock = QLineEdit(); txt_stock.setPlaceholderText("Tồn kho (+)")
        
        txt_unit = QLineEdit(); txt_unit.setPlaceholderText("Đơn vị (ml)")
        txt_price = QLineEdit(); txt_price.setPlaceholderText("Giá nhập/đv")
        
        cb_type = QComboBox()
        cb_type.addItems(["Lâu dài", "Trong ngày"])
        
        btn_remove = QPushButton("❌")
        btn_remove.setFixedWidth(30)
        btn_remove.clicked.connect(lambda: self.remove_ingredient_row(row_widget))

        h_layout.addWidget(txt_name)
        h_layout.addWidget(txt_qty)
        h_layout.addWidget(txt_stock) # Đẩy vào giao diện
        h_layout.addWidget(txt_unit)
        h_layout.addWidget(txt_price)
        h_layout.addWidget(cb_type)
        h_layout.addWidget(btn_remove)

        self.ingredients_layout.addWidget(row_widget)
        
        self.ing_rows.append({
            'widget': row_widget, 'name': txt_name, 'qty': txt_qty, 
            'stock': txt_stock, # Nhớ lưu lại ô này để tý lấy dữ liệu
            'unit': txt_unit, 'price': txt_price, 'type': cb_type
        })

    def remove_ingredient_row(self, widget):
        widget.deleteLater()
        self.ing_rows = [row for row in self.ing_rows if row['widget'] != widget]

    def save_data(self):
        p_name = self.txt_name.text().strip()
        p_price = self.txt_price.text().strip()
        
        if not p_name or not p_price.isdigit():
            QMessageBox.warning(self, "Lỗi", "Nhập tên và giá bán món hợp lệ!")
            return
            
        session = get_session()
        try:
            # Lưu Món ăn mới
            new_p = SanPham(ten_sp=p_name, gia_ban=float(p_price))
            session.add(new_p)
            session.flush() 
            
            # Xử lý từng dòng nguyên liệu
            for row in self.ing_rows:
                name = row['name'].text().strip()
                qty = row['qty'].text().strip()
                stock = row['stock'].text().strip() # Lấy số lượng tồn
                unit = row['unit'].text().strip()
                price = row['price'].text().strip()
                i_type = row['type'].currentText()
                
                if not name or not qty: continue 
                
                # Check định dạng số (cho phép nhập số thập phân)
                val_stock = float(stock) if stock.replace('.','',1).isdigit() else 0.0
                val_price = float(price) if price.replace('.','',1).isdigit() else 0.0
                
                ing = session.query(NguyenLieu).filter_by(ten_nl=name).first()
                if not ing:
                    # NẾU CHƯA CÓ: Đẩy thẳng số lượng tồn vừa nhập vào Kho
                    ing = NguyenLieu(
                        ten_nl=name, 
                        don_vi_tinh=unit if unit else "đv",
                        gia_nhap=val_price,
                        loai_nl=i_type,
                        so_luong_ton=val_stock 
                    )
                    session.add(ing)
                    session.flush() 
                else:
                    # NẾU CÓ RỒI: Cộng dồn thêm số lượng tồn kho (nếu user có nhập)
                    if val_stock > 0:
                        ing.so_luong_ton += val_stock
                        session.add(ing)
                
                # Lưu định mức vào Công thức
                session.add(CongThuc(ma_sp=new_p.id, ma_nl=ing.id, dinh_muc=float(qty)))
            
            session.commit()
            self.accept()
        except Exception as e:
            session.rollback()
            QMessageBox.critical(self, "Lỗi Database", str(e))
        finally:
            session.close()

# ==========================================
# 2. MÀN HÌNH QUẢN LÝ (CÂY DANH SÁCH)
# ==========================================
class ProductManager(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Quản Lý Danh Mục Món (Tree View)")
        self.resize(600, 500)
        
        layout = QVBoxLayout(self)
        
        toolbar = QHBoxLayout()
        btn_add = QPushButton("➕ Thêm Món Mới")
        btn_add.clicked.connect(self.add_product)
        toolbar.addWidget(btn_add)
        layout.addLayout(toolbar)
        
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Tên Món / Thành Phần", "Giá Bán / Định Mức"])
        self.tree.header().setSectionResizeMode(0, QHeaderView.Stretch)
        layout.addWidget(self.tree)
        
        self.load_data()
        
    def load_data(self):
        self.tree.clear()
        session = get_session()
        products = session.query(SanPham).all()
        
        for p in products:
            p_item = QTreeWidgetItem([f"☕ {p.ten_sp}", f"{p.gia_ban:,.0f} VNĐ"])
            p_item.setForeground(0, QColor("#E67E22"))
            font = p_item.font(0)
            font.setBold(True)
            font.setPointSize(11)
            p_item.setFont(0, font)
            
            for ct in p.cong_thuc:
                child = QTreeWidgetItem([f"  ↳ {ct.nguyen_lieu.ten_nl}", f"{ct.dinh_muc} {ct.nguyen_lieu.don_vi_tinh}"])
                child.setForeground(0, QColor("#7F8C8D"))
                p_item.addChild(child)
                
            self.tree.addTopLevelItem(p_item)
        session.close()
        
    def add_product(self):
        dlg = ProductForm(self)
        if dlg.exec() == QDialog.Accepted:
            self.load_data()