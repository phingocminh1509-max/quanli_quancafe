from PySide6.QtWidgets import (QDialog, QVBoxLayout, QTableWidget, 
                               QTableWidgetItem, QHeaderView, QLabel, QPushButton, QMessageBox)
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor

from database.db_config import get_session
from database.models import NguyenLieu

class InventoryDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Quản Lý Tồn Kho Nguyên Liệu")
        self.resize(650, 450)

        layout = QVBoxLayout(self)
        self.setStyleSheet("background-color: #1E1E2E; color: white;")
        
        # Tiêu đề có kèm hướng dẫn
        title = QLabel("<b>TÌNH TRẠNG KHO HIỆN TẠI</b><br><span style='font-size: 13px; color: #BDC3C7;'>(💡 Mẹo: Nhấp đúp chuột vào cột Tồn Kho để sửa trực tiếp)</span>")
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("font-size: 18px; color: #3498DB; margin-bottom: 10px;")
        layout.addWidget(title)

        # Khởi tạo bảng
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["Tên Nguyên Liệu", "Tồn Kho (Sửa được)", "Đơn Vị", "Giá Nhập", "Phân Loại"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.table.setStyleSheet("""
            QTableWidget {
                background-color: #2D2D3F; border: none; border-radius: 10px;
                gridline-color: #3E3E55; color: white; font-size: 13px;
            }
            QTableWidget::item { padding: 5px; border-bottom: 1px solid #3E3E55; }
            QHeaderView::section {
                background-color: #1A1A24; color: #A1A1AA;
                padding: 8px; border: none; font-weight: bold; font-size: 13px;
            }
        """)
        layout.addWidget(self.table)

        close_btn = QPushButton("Đóng")
        close_btn.setMinimumHeight(40)
        close_btn.setStyleSheet("background-color: #34495E; font-weight: bold; font-size: 14px; border-radius: 8px;")
        close_btn.clicked.connect(self.accept)
        layout.addWidget(close_btn)

        # Lắng nghe sự kiện Edit ô trên bảng
        self.table.itemChanged.connect(self.on_item_changed)
        self.load_data()

    def load_data(self):
        """Tải dữ liệu lên bảng và phân quyền sửa"""
        self.table.blockSignals(True) # Chặn tín hiệu để tool không bị ngáo khi tự điền data
        session = get_session()
        ingredients = session.query(NguyenLieu).all()
        
        self.table.setRowCount(len(ingredients))
        
        for row_idx, item in enumerate(ingredients):
            # Cột 0: Tên (KHÓA, Không cho sửa)
            name_item = QTableWidgetItem(item.ten_nl)
            name_item.setFlags(name_item.flags() & ~Qt.ItemIsEditable)
            self.table.setItem(row_idx, 0, name_item)
            
            # Cột 1: TỒN KHO (MỞ KHÓA, cho phép sửa)
            stock_item = QTableWidgetItem(str(item.so_luong_ton))
            stock_item.setData(Qt.UserRole, item.id) # Lưu ngầm ID vào ô này để tý update
            stock_item.setBackground(QColor("#35354A")) # Làm nền xám nhạt để biết là ô này sửa được
            if item.so_luong_ton < 10:
                stock_item.setForeground(QColor("#E74C3C")) # Hết hàng -> Màu đỏ
            else:
                stock_item.setForeground(QColor("#F1C40F")) # Còn hàng -> Màu vàng
            self.table.setItem(row_idx, 1, stock_item)
            
            # Cột 2, 3, 4: (KHÓA, Không cho sửa)
            unit_item = QTableWidgetItem(item.don_vi_tinh)
            unit_item.setFlags(unit_item.flags() & ~Qt.ItemIsEditable)
            self.table.setItem(row_idx, 2, unit_item)
            
            price_item = QTableWidgetItem(f"{item.gia_nhap:,.0f} đ")
            price_item.setFlags(price_item.flags() & ~Qt.ItemIsEditable)
            self.table.setItem(row_idx, 3, price_item)
            
            type_item = QTableWidgetItem(item.loai_nl)
            type_item.setFlags(type_item.flags() & ~Qt.ItemIsEditable)
            type_item.setForeground(QColor("#E67E22") if item.loai_nl == "Trong ngày" else QColor("#27AE60"))
            self.table.setItem(row_idx, 4, type_item)
            
        session.close()
        self.table.blockSignals(False) # Mở lại tín hiệu lắng nghe

    def on_item_changed(self, item):
        """Kích hoạt khi Thu ngân sửa số lượng rồi ấn Enter"""
        col = item.column()
        if col == 1: # Chắc chắn là đang sửa cột Tồn kho
            ing_id = item.data(Qt.UserRole)
            new_val_str = item.text().replace(',', '').strip()
            
            try:
                new_val = float(new_val_str)
                if new_val < 0: raise ValueError
                
                # Lưu vào Database
                session = get_session()
                ing = session.query(NguyenLieu).get(ing_id)
                if ing:
                    ing.so_luong_ton = new_val
                    session.commit()
                session.close()
                self.load_data() # Load lại cho format chữ ngay ngắn
            except ValueError:
                QMessageBox.warning(self, "Lỗi Nhập Liệu", "Vui lòng nhập số hợp lệ (Lớn hơn hoặc bằng 0)!")
                self.load_data() # Nếu nhập sai thì reset về số cũ