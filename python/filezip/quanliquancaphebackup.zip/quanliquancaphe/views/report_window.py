from PySide6.QtWidgets import (QDialog, QVBoxLayout, QLabel, QPushButton, QFrame, QHBoxLayout)
from PySide6.QtCore import Qt
from controllers.report_controller import get_revenue_summary

class ReportDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Báo Cáo Hoạt Động Kinh Doanh")
        self.resize(500, 550)
        self.setStyleSheet("background-color: #1E1E2E; color: white;")

        layout = QVBoxLayout(self)

        title = QLabel("<b>📊 KẾT QUẢ KINH DOANH</b>")
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("font-size: 24px; color: #F1C40F; margin-bottom: 15px;")
        layout.addWidget(title)

        data = get_revenue_summary()

        def create_info_block(label_text, value_text, color, is_main=False):
            frame = QFrame()
            # Khung màu tối, bo góc lớn chuẩn Glassmorphism
            frame.setStyleSheet("""
                QFrame {
                    background-color: #2D2D3F; 
                    border-radius: 12px; 
                    border: 1px solid #3E3E55;
                }
            """)
            vbox = QVBoxLayout(frame)
            vbox.setSpacing(8)
            vbox.setContentsMargins(15, 20, 15, 20)
            
            lbl = QLabel(label_text)
            lbl.setAlignment(Qt.AlignCenter)
            lbl.setStyleSheet("font-size: 14px; color: #A1A1AA; font-weight: bold; border: none;")
            
            val = QLabel(value_text)
            val.setAlignment(Qt.AlignCenter)
            font_size = "36px" if is_main else "24px"
            val.setStyleSheet(f"font-size: {font_size}; font-weight: 900; color: {color}; border: none;")
            
            vbox.addWidget(lbl)
            vbox.addWidget(val)
            return frame

        # Dòng 1: Tổng đơn và Tổng Thu
        row1 = QHBoxLayout()
        row1.addWidget(create_info_block("TỔNG SỐ ĐƠN", f"{data['total_orders']}", "#3498DB"))
        row1.addWidget(create_info_block("DOANH THU", f"{data['total_revenue']:,.0f} đ", "#2ECC71"))
        layout.addLayout(row1)

        # Dòng 2: Các khoản trừ
        row2 = QHBoxLayout()
        row2.addWidget(create_info_block("CHI PHÍ VỐN", f"-{data['total_cost']:,.0f} đ", "#E67E22"))
        row2.addWidget(create_info_block("THUẾ (10%)", f"-{data['total_tax']:,.0f} đ", "#E74C3C"))
        layout.addLayout(row2)

        # Khối Lợi Nhuận Ròng (To nhất)
        layout.addWidget(create_info_block("LỢI NHUẬN RÒNG (BỎ TÚI)", f"{data['net_profit']:,.0f} VNĐ", "#1ABC9C", is_main=True))

        layout.addStretch()

        close_btn = QPushButton("Đóng Báo Cáo")
        close_btn.setMinimumHeight(45)
        close_btn.setStyleSheet("background-color: #34495E; font-weight: bold; font-size: 16px; border-radius: 10px;")
        close_btn.clicked.connect(self.accept)
        layout.addWidget(close_btn)