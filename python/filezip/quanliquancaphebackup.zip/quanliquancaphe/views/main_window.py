import sys
import os
from PySide6.QtWidgets import (QApplication, QLineEdit, QMainWindow, QWidget, QHBoxLayout, 
                               QVBoxLayout, QPushButton, QTableWidget, 
                               QTableWidgetItem, QHeaderView, QLabel, QMessageBox,
                               QGridLayout, QScrollArea, QFrame, QDialog)
from PySide6.QtCore import Qt, QTimer, QUrl
from PySide6.QtGui import QCursor, QFont, QColor
from PySide6.QtMultimedia import QSoundEffect

# ================= HÀM TÍNH TOÁN SỐ LY CÒN LẠI =================
def calculate_available_servings(product):
    if not product.cong_thuc: return -1
    min_servings = float('inf')
    for ct in product.cong_thuc:
        if ct.dinh_muc > 0 and ct.nguyen_lieu:
            servings = int(ct.nguyen_lieu.so_luong_ton / ct.dinh_muc)
            if servings < min_servings:
                min_servings = servings
    return min_servings if min_servings != float('inf') else 0

# ================= CLASS TẠO THẺ SẢN PHẨM =================
class ProductCard(QFrame):
    def __init__(self, product, available_qty, click_callback):
        super().__init__()
        self.product = product
        self.setFixedSize(230, 110)
        self.setCursor(QCursor(Qt.PointingHandCursor))
        self.click_callback = click_callback
        
        self.setStyleSheet("""
            ProductCard { background-color: #2D2D3F; border-radius: 12px; border: 1px solid #3E3E55; }
            ProductCard:hover { border: 2px solid #3498DB; background-color: #35354A; }
        """)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)

        # Bộ não Icon
        name_lower = product.ten_sp.lower()
        icon = "📦"
        if any(x in name_lower for x in ["cà phê", "cafe", "bạc xỉu", "espresso", "đen"]): icon = "☕"
        elif any(x in name_lower for x in ["trà", "tea", "matcha", "đào"]): icon = "🍵"
        elif any(x in name_lower for x in ["sinh tố", "nước ép", "vải", "cam", "chanh"]): icon = "🍹"
        elif any(x in name_lower for x in ["bánh", "cake", "mì", "sandwich", "croissant"]): icon = "🍰"
        elif any(x in name_lower for x in ["cơm", "phở", "bún", "mì xào", "lẩu"]): icon = "🍲"
        elif any(x in name_lower for x in ["khoai tây", "hướng dương", "khô bò", "snack"]): icon = "🍟"

        img_label = QLabel(icon)
        img_label.setFixedSize(65, 65)
        img_label.setAlignment(Qt.AlignCenter)
        img_label.setStyleSheet("background-color: #1E1E2E; border-radius: 12px; font-size: 35px; border: none;")
        layout.addWidget(img_label)

        info_layout = QVBoxLayout()
        info_layout.setSpacing(2)
        
        name_lbl = QLabel(product.ten_sp)
        name_lbl.setStyleSheet("color: white; font-weight: bold; font-size: 14px; border: none;")
        name_lbl.setWordWrap(True)
        
        price_lbl = QLabel(f"{product.gia_ban:,.0f} đ")
        price_lbl.setStyleSheet("color: #F1C40F; font-size: 13px; font-weight: bold; border: none;")
        
        stock_lbl = QLabel()
        stock_lbl.setStyleSheet("border: none;")
        if available_qty == 0:
            stock_lbl.setText("HẾT NGUYÊN LIỆU")
            stock_lbl.setStyleSheet("color: #E74C3C; font-size: 11px; font-weight: bold; border: none;")
            self.setEnabled(False)
            self.setStyleSheet("ProductCard { background-color: #1A1A24; border-radius: 12px; border: 1px solid #E74C3C; opacity: 0.5; }")
        elif available_qty == -1:
            stock_lbl.setText("Chưa có công thức")
            stock_lbl.setStyleSheet("color: #95A5A6; font-size: 11px; border: none;")
        else:
            stock_lbl.setText(f"Có thể pha: {int(available_qty)} ly")
            stock_lbl.setStyleSheet("color: #2ECC71; font-size: 11px; font-weight: bold; border: none;")

        info_layout.addWidget(name_lbl)
        info_layout.addWidget(price_lbl)
        info_layout.addWidget(stock_lbl)
        layout.addLayout(info_layout)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton and self.isEnabled():
            self.click_callback()

# ================= CLASS CỬA SỔ CHÍNH =================
class POSWindow(QMainWindow):
    def __init__(self, current_user):
        super().__init__()
        self.user = current_user
        self.setWindowTitle("Hệ Thống Quản Lý Quán Cà Phê - Bản Thương Mại")
        self.resize(1200, 750)
        self.setStyleSheet("background-color: #1E1E2E; color: white;") 

        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QHBoxLayout(main_widget)
        main_layout.setContentsMargins(15, 15, 15, 15)
        main_layout.setSpacing(15)

        # ================= NỬA TRÁI: MENU =================
        left_panel = QWidget()
        left_panel.setStyleSheet("background-color: #1A1A24; border-radius: 15px;") 
        left_layout = QVBoxLayout(left_panel)
        
        header_layout = QHBoxLayout()
        title_lbl = QLabel("📋 DANH MỤC MÓN")
        title_lbl.setStyleSheet("font-size: 18px; font-weight: bold; color: #3498DB;")
        header_layout.addWidget(title_lbl)
        
        self.btn_logout = QPushButton(f"🚪 Đăng xuất ({self.user.ten_dang_nhap})")
        self.btn_logout.setStyleSheet("background-color: #C0392B; color: white; font-weight: bold; padding: 8px; border-radius: 6px;")
        self.btn_logout.clicked.connect(self.logout)
        header_layout.addWidget(self.btn_logout, alignment=Qt.AlignRight)
        left_layout.addLayout(header_layout)

        # Thanh Tìm Kiếm
        search_layout = QHBoxLayout()
        self.search_bar = QLineEdit()
        self.search_bar.setPlaceholderText("🔍 Nhập tên món để tìm kiếm nhanh...")
        self.search_bar.setStyleSheet("""
            QLineEdit { background-color: #2D2D3F; border: 1px solid #3E3E55; border-radius: 20px; padding: 10px 15px; color: white; font-size: 14px; }
            QLineEdit:focus { border: 1px solid #3498DB; background-color: #35354A; }
        """)
        self.search_bar.textChanged.connect(self.filter_products)
        search_layout.addWidget(self.search_bar)
        left_layout.addLayout(search_layout)
        
        # Grid Món Ăn
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setStyleSheet("QScrollArea { border: none; background-color: transparent; }")
        
        self.grid_widget = QWidget()
        self.grid_widget.setStyleSheet("background-color: transparent;")
        self.grid_layout = QGridLayout(self.grid_widget)
        self.grid_layout.setSpacing(12)
        self.grid_layout.setAlignment(Qt.AlignTop)

        self.refresh_product_grid() 
        scroll_area.setWidget(self.grid_widget)
        left_layout.addWidget(scroll_area)

        # Nút Chức Năng Dưới Cùng
        func_layout = QHBoxLayout()
        self.inventory_btn = QPushButton("📦 KHO")
        self.history_btn = QPushButton("📜 LỊCH SỬ")
        self.report_btn = QPushButton("📊 BÁO CÁO")
        self.menu_btn = QPushButton("⚙️ MENU")
        self.admin_btn = QPushButton("🛡️ HỆ THỐNG") # Nút mới!
        
        for btn in [self.inventory_btn, self.history_btn, self.report_btn, self.menu_btn, self.admin_btn]:
            btn.setMinimumHeight(45)
            btn.setStyleSheet("background-color: #34495E; color: white; font-weight: bold; border-radius: 8px;")
            func_layout.addWidget(btn)
        
        self.admin_btn.setStyleSheet("background-color: #900C3F; color: white; font-weight: bold; border-radius: 8px;")

        self.inventory_btn.clicked.connect(self.show_inventory_dialog)
        self.history_btn.clicked.connect(self.show_history_dialog)
        self.report_btn.clicked.connect(self.show_report)
        self.menu_btn.clicked.connect(self.show_product_manager)
        self.admin_btn.clicked.connect(self.show_admin_settings)
        
        left_layout.addLayout(func_layout)

        # DÒNG CỐT TỬ ĐỂ HIỂN THỊ NỬA TRÁI (Lúc nãy bro lỡ tay xóa mất dòng này)
        main_layout.addWidget(left_panel, stretch=6)

        # ================= NỬA PHẢI: HÓA ĐƠN =================
        right_panel = QWidget()
        right_panel.setStyleSheet("background-color: #1A1A24; border-radius: 15px;")
        right_layout = QVBoxLayout(right_panel)
        
        inv_title = QLabel("🧾 HÓA ĐƠN")
        inv_title.setStyleSheet("font-size: 18px; font-weight: bold; color: #2ECC71;")
        inv_title.setAlignment(Qt.AlignCenter)
        right_layout.addWidget(inv_title)

        self.order_table = QTableWidget(0, 4)
        self.order_table.setHorizontalHeaderLabels(["Tên Món", "SL", "Thành Tiền", ""])
        self.order_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.order_table.setColumnWidth(1, 50)
        self.order_table.setColumnWidth(2, 90)
        self.order_table.setColumnWidth(3, 80)
        self.order_table.setStyleSheet("""
            QTableWidget { background-color: #2D2D3F; border: none; border-radius: 10px; gridline-color: #3E3E55; color: white; font-size: 13px; }
            QTableWidget::item { padding: 5px; border-bottom: 1px solid #3E3E55; }
            QHeaderView::section { background-color: #2C3E50; color: #A1A1AA; padding: 8px; border: none; font-weight: bold; font-size: 13px; }
        """)
        right_layout.addWidget(self.order_table)

        self.total_label = QLabel("Tổng cộng: 0 Đ")
        self.total_label.setStyleSheet("font-size: 20px; font-weight: bold; color: #E74C3C; background-color: transparent;")
        right_layout.addWidget(self.total_label)

        self.checkout_btn = QPushButton("XUẤT HÓA ĐƠN")
        self.checkout_btn.setMinimumHeight(60)
        self.checkout_btn.setStyleSheet("background-color: #27AE60; color: white; font-size: 18px; font-weight: bold; border-radius: 10px;")
        self.checkout_btn.clicked.connect(self.handle_checkout)
        right_layout.addWidget(self.checkout_btn)

        main_layout.addWidget(right_panel, stretch=4)
        self.apply_permissions()

        # ================= KHỞI TẠO ÂM THANH =================
        self.sound_beep = QSoundEffect()
        if os.path.exists("sounds/beep.wav"): self.sound_beep.setSource(QUrl.fromLocalFile("sounds/beep.wav"))
        self.sound_cash = QSoundEffect()
        if os.path.exists("sounds/cash.wav"): self.sound_cash.setSource(QUrl.fromLocalFile("sounds/cash.wav"))

    # ================= CÁC HÀM XỬ LÝ =================
    def apply_permissions(self):
        role = self.user.chuc_vu
        if role == "Nhân viên":
            self.inventory_btn.setVisible(False)
            self.report_btn.setVisible(False)
            self.menu_btn.setVisible(False)
            self.admin_btn.setVisible(False) # Giấu nút hệ thống
            self.setWindowTitle(f"POS - Nhân viên: {self.user.ten_nv}")
        else:
            self.setWindowTitle(f"Hệ thống Quản lý - {role}: {self.user.ten_nv}")

    def filter_products(self, text):
        search_text = text.lower().strip()
        for i in range(self.grid_layout.count()):
            item = self.grid_layout.itemAt(i)
            if item.widget():
                card = item.widget()
                if search_text in card.product.ten_sp.lower():
                    card.show()
                else:
                    card.hide()

    def refresh_product_grid(self):
        while self.grid_layout.count():
            item = self.grid_layout.takeAt(0)
            if item.widget(): item.widget().deleteLater()
                
        from database.db_config import get_session
        from database.models import SanPham
        session = get_session()
        db_products = session.query(SanPham).all()
        
        row, col = 0, 0
        for product in db_products:
            avail_qty = calculate_available_servings(product)
            p_data = {'name': product.ten_sp, 'price': product.gia_ban}
            card = ProductCard(product, avail_qty, lambda chk=False, p=p_data: self.add_to_order(p))
            self.grid_layout.addWidget(card, row, col)
            col += 1
            if col > 1:
                col = 0
                row += 1
        session.close()

    def highlight_total(self):
        original_style = self.total_label.styleSheet()
        highlight_style = original_style + "background-color: rgba(39, 174, 96, 0.4); border-radius: 8px;"
        self.total_label.setStyleSheet(highlight_style)
        QTimer.singleShot(200, lambda: self.total_label.setStyleSheet(original_style))

    def update_grand_total(self):
        grand_total = 0
        for row in range(self.order_table.rowCount()):
            line_total_str = self.order_table.item(row, 2).text().replace(",", "")
            if line_total_str.strip(): 
                grand_total += float(line_total_str)
        tax = grand_total * 0.10
        total_to_pay = grand_total + tax
        detail_text = (
            f"<div style='text-align: right; background-color: transparent;'>"
            f"<span style='font-size: 14px; color: #BDC3C7;'>Tổng tiền món: {int(grand_total):,.0f} đ</span><br>"
            f"<span style='font-size: 14px; color: #E74C3C;'>Thuế VAT (10%): +{int(tax):,.0f} đ</span><br>"
            f"<b style='font-size: 24px; color: #27AE60;'>CẦN THANH TOÁN: {int(total_to_pay):,.0f} Đ</b>"
            f"</div>"
        )
        self.total_label.setText(detail_text)

    def change_qty(self, row, delta, price):
        current_qty = int(self.order_table.item(row, 1).text())
        new_qty = current_qty + delta
        if new_qty <= 0:
            self.order_table.removeRow(row)
        else:
            self.order_table.setItem(row, 1, QTableWidgetItem(str(new_qty)))
            self.order_table.setItem(row, 2, QTableWidgetItem(f"{int(new_qty * price):,}"))
        self.update_grand_total()
        self.sound_beep.play()
        self.highlight_total()

    def create_action_buttons(self, row, product_price):
        container = QWidget()
        layout = QHBoxLayout(container)
        layout.setContentsMargins(2, 2, 2, 2)
        layout.setSpacing(5)
        btn_plus = QPushButton("+")
        btn_minus = QPushButton("-")
        style = "font-weight: bold; min-width: 30px; max-width: 30px; background-color: #34495E; color: white; border-radius: 4px;"
        btn_plus.setStyleSheet(style)
        btn_minus.setStyleSheet(style)
        btn_plus.clicked.connect(lambda: self.change_qty(row, 1, product_price))
        btn_minus.clicked.connect(lambda: self.change_qty(row, -1, product_price))
        layout.addWidget(btn_minus)
        layout.addWidget(btn_plus)
        return container

    def add_to_order(self, product):
        for row in range(self.order_table.rowCount()):
            if self.order_table.item(row, 0).text() == product['name']:
                self.change_qty(row, 1, product['price'])
                return
        row_idx = self.order_table.rowCount()
        self.order_table.insertRow(row_idx)
        self.order_table.setItem(row_idx, 0, QTableWidgetItem(product['name']))
        self.order_table.setItem(row_idx, 1, QTableWidgetItem("1"))
        self.order_table.setItem(row_idx, 2, QTableWidgetItem(f"{int(product['price']):,}"))
        action_widget = self.create_action_buttons(row_idx, product['price'])
        self.order_table.setCellWidget(row_idx, 3, action_widget)
        self.update_grand_total()
        self.sound_beep.play()
        self.highlight_total()

    def handle_checkout(self):
        import random
        if self.order_table.rowCount() == 0:
            QMessageBox.warning(self, "Cảnh báo", "Hóa đơn đang trống!")
            return
        order_items = []
        grand_total = 0
        for row in range(self.order_table.rowCount()):
            name = self.order_table.item(row, 0).text()
            qty = int(self.order_table.item(row, 1).text())
            line_total = float(self.order_table.item(row, 2).text().replace(",", ""))
            unit_price = line_total / qty
            grand_total += line_total
            order_items.append({'name': name, 'qty': qty, 'price': unit_price})
            
        vat_tax = grand_total * 0.10
        total_to_pay = grand_total + vat_tax
            
        dialog = QDialog(self)
        dialog.setWindowTitle("Quét mã thanh toán")
        dialog.setFixedSize(400, 550)
        dialog.setStyleSheet("background-color: #1E1E2E; color: white;")
        layout = QVBoxLayout(dialog)
        title = QLabel(f"<b>CẦN THANH TOÁN (+10% VAT): {int(total_to_pay):,.0f} Đ</b>")
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("font-size: 18px; color: #2ECC71; margin-top: 10px;")
        layout.addWidget(title)

        qr_label = QLabel("Đang tải mã QR...")
        qr_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(qr_label)

        from utils.qr_generator import generate_vietqr_pixmap
        order_code = f"CF{random.randint(1000,9999)}" 
        pixmap = generate_vietqr_pixmap(total_to_pay, f"Thanh toan don {order_code}")
        if pixmap:
            qr_label.setPixmap(pixmap.scaled(350, 350, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        
        confirm_btn = QPushButton("ĐÃ NHẬN TIỀN (CHỐT ĐƠN)")
        confirm_btn.setMinimumHeight(60)
        confirm_btn.setStyleSheet("background-color: #27AE60; color: white; font-weight: bold; font-size: 16px; border-radius: 8px;")
        confirm_btn.clicked.connect(dialog.accept)
        layout.addWidget(confirm_btn)

        cancel_btn = QPushButton("Khách chưa chuyển (Hủy)")
        cancel_btn.setMinimumHeight(40)
        cancel_btn.setStyleSheet("background-color: #E74C3C; color: white; border-radius: 8px;")
        cancel_btn.clicked.connect(dialog.reject)
        layout.addWidget(cancel_btn)

        if dialog.exec() == QDialog.Accepted:
            from controllers.pos_controller import process_checkout
            success, message = process_checkout(order_items)
            if success:
                self.sound_cash.play()
                QMessageBox.information(self, "Thành công", f"ĐÃ CHỐT ĐƠN HÀNG!\n\nChi tiết:\n{message}\n\n(Lưu ý: Vui lòng check Lịch sử giao dịch để lấy Mã Hóa Đơn nếu cần).")
                self.order_table.setRowCount(0)
                self.update_grand_total()
                self.refresh_product_grid() # Cập nhật lại kho
            else:
                QMessageBox.warning(self, "Lỗi Database", message)

    def show_report(self):
        from views.report_window import ReportDialog
        ReportDialog(self).exec()

    def show_product_manager(self):
        from views.product_manager import ProductManager
        ProductManager(self).exec()
        self.refresh_product_grid()

    def show_inventory_dialog(self):
        from views.ingredient_manager import InventoryDialog
        InventoryDialog(self).exec()
        self.refresh_product_grid()

    def show_admin_settings(self):
        from views.admin_settings import AdminSettingsDialog
        AdminSettingsDialog(self).exec()
        self.apply_permissions() # Lỡ Admin đổi quyền của chính mình

    def logout(self):
        from utils.session_manager import clear_session
        confirm = QMessageBox.question(self, "Đăng xuất", "Bạn có chắc chắn muốn đăng xuất?", QMessageBox.Yes | QMessageBox.No)
        if confirm == QMessageBox.Yes:
            clear_session()
            self.is_logged_out = True
            self.close()

    def show_history_dialog(self):
        """Mở cửa sổ xem lịch sử giao dịch"""
        from views.history_window import HistoryDialog
        dialog = HistoryDialog(self)
        dialog.exec()