from database.db_config import get_session
from database.models import HoaDon

def get_revenue_summary():
    """Lấy tổng doanh thu, chi phí, thuế và lợi nhuận ròng"""
    session = get_session()
    try:
        orders = session.query(HoaDon).all()
        
        total_orders = len(orders)
        
        # Doanh thu thực tế là tổng tiền khách đã thanh toán
        total_revenue = sum(o.thanh_tien for o in orders if o.thanh_tien)
        
        # Thuế
        total_tax = sum(o.thue for o in orders if o.thue)
        
        # Tính chi phí gốc (Móc vào từng Chi tiết hóa đơn -> Sản phẩm -> Tính giá vốn)
        total_cost = 0
        for o in orders:
            for ct in o.chi_tiet:
                total_cost += ct.san_pham.calculate_base_cost() * ct.so_luong
                
        # Lợi nhuận RÒNG = Thanh toán (Đã trừ KM, có Thuế) - Thuế - Chi phí vốn
        net_profit = (total_revenue - total_tax) - total_cost
        
        return {
            'total_orders': total_orders,
            'total_revenue': total_revenue,
            'total_cost': total_cost,
            'total_tax': total_tax,
            'net_profit': net_profit
        }
    except Exception as e:
        print(f"Lỗi tính báo cáo: {e}")
        return {
            'total_orders': 0, 'total_revenue': 0, 'total_cost': 0, 'total_tax': 0, 'net_profit': 0
        }
    finally:
        session.close()