from database.db_config import get_session
from database.models import SanPham, HoaDon, ChiTietHoaDon, NguyenLieu, KhuyenMai
from datetime import date

from utils.logger import log_error, log_info

def process_checkout(order_items):
    """Xử lý thanh toán: Tạo hóa đơn, Trừ kho, Áp dụng Khuyến mãi, Tính thuế"""
    if not order_items:
        return False, "Hóa đơn đang trống!"

    session = get_session()
    try:
        new_order = HoaDon(tong_tien=0, giam_gia=0, thue=0, thanh_tien=0)
        session.add(new_order)
        session.flush() # Lấy ID hóa đơn tạm

        grand_total = 0

        # 1. Quét món ăn và Trừ kho
        for item in order_items:
            product = session.query(SanPham).filter_by(ten_sp=item['name']).first()
            if not product:
                continue
            
            qty = item['qty']
            line_total = qty * item['price']
            grand_total += line_total

            detail = ChiTietHoaDon(
                ma_hd=new_order.id,
                ma_sp=product.id,
                so_luong=qty,
                don_gia=item['price'],
                thanh_tien=line_total
            )
            session.add(detail)

            # ÉP BUỘC Trừ kho (SQLAlchemy sẽ không bị lười nữa)
            for ct in product.cong_thuc:
                ing = session.query(NguyenLieu).get(ct.ma_nl)
                if ing:
                    ing.so_luong_ton -= (qty * ct.dinh_muc)
                    session.add(ing)

        new_order.tong_tien = grand_total

        # 2. KIỂM TRA VÀ ÁP DỤNG KHUYẾN MÃI (MARKETING MODULE)
        today = date.today()
        kms = session.query(KhuyenMai).filter(
            KhuyenMai.trang_thai == 'Đang chạy',
            KhuyenMai.ngay_bat_dau <= today,
            KhuyenMai.ngay_ket_thuc >= today,
            KhuyenMai.dk_tong_tien_tu <= grand_total # Kiểm tra đủ điều kiện hóa đơn
        ).all()

        giam_gia = 0
        if kms:
            # Ưu tiên lấy khuyến mãi đầu tiên thỏa mãn
            km = kms[0]
            if km.kieu_giam == 'PhanTram':
                giam_gia = grand_total * km.gia_tri_giam
            else:
                giam_gia = km.gia_tri_giam
            
            # Cắt ngọn nếu vượt quá mức giảm tối đa
            if km.toi_da_giam and giam_gia > km.toi_da_giam:
                giam_gia = km.toi_da_giam
            
            new_order.ma_km = km.id
            new_order.giam_gia = giam_gia

        # 3. Tính Thành Tiền và Thuế
        new_order.thue = (grand_total - giam_gia) * 0.10
        new_order.thanh_tien = (grand_total - giam_gia) + new_order.thue
        
        # 4. Chốt hạ
        session.commit()
        # ---> GHI LOG DOANH THU 
        # Trích xuất tên các món ăn ra để ghi vào file
        danh_sach_mon = ", ".join([f"{item['qty']}x {item['name']}" for item in order_items])
        log_info(f"CHỐT ĐƠN THÀNH CÔNG: Thu {new_order.thanh_tien:,.0f}đ | Chi tiết: {danh_sach_mon}")

        return True, f"Chốt đơn thành công!\nTổng tiền món: {grand_total:,.0f}đ\nThuế VAT (10%): +{new_order.thue:,.0f}đ\n-------------------\nKHÁCH CẦN TRẢ: {new_order.thanh_tien:,.0f}đ"
    
    except Exception as e:
        session.rollback()
        log_error(f"LỖI CHỐT ĐƠN: Văng app do {str(e)}") # ---> GHI LOG LỖI APP
        return False, f"Lỗi hệ thống: {str(e)}"
    finally:
        session.close()