from database.db_config import get_session
from database.models import NhanVien
from utils.logger import log_info, log_error # <--- Thêm dòng này

def authenticate_user(username, password):
    session = get_session()
    try:
        user = session.query(NhanVien).filter_by(
            ten_dang_nhap=username, 
            mat_khau=password
        ).first()
        
        if user:
            # ---> GHI LOG ĐĂNG NHẬP THÀNH CÔNG
            log_info(f"ĐĂNG NHẬP: '{user.ten_nv}' (Chức vụ: {user.chuc_vu}) vừa truy cập hệ thống.")
            return user
        else:
            # ---> GHI LOG CẢNH BÁO BẢO MẬT
            log_error(f"CẢNH BÁO BẢO MẬT: Có người cố gắng đăng nhập thất bại với tài khoản '{username}'.")
            return None
    except Exception as e:
        log_error(f"LỖI DATABASE: Không thể kết nối để đăng nhập. Chi tiết: {e}")
        return None
    finally:
        session.close()